# 极简记收入 (Streamlit)

## 运行（本地）
```bash
pip install -r requirements.txt
streamlit run app.py
